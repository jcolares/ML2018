import numpy as np


def cofi_cost_func(params, Y, R, num_users, num_movies, num_features, Lambda):

    # Obtém as matrizes X e Theta a partir dos params
    X = np.array(params[:num_movies*num_features]).reshape(num_features, num_movies).T.copy()
    Theta = np.array(params[num_movies*num_features:]).reshape(num_features, num_users).T.copy()


    # Você deve retornar os seguintes valores corretamente
    J = 0
    X_grad = np.zeros(X.shape)
    Theta_grad = np.zeros(Theta.shape)

    # ====================== SEU CÓDIGO AQUI ======================
    # Instruções: calcular a função de custo regularizada e gradiente  
    # para a filtragem colaborativa. Concretamente, você deve primeiro
    # implementar a função de custo. Depois disso, você deve implementar o
    # gradiente. 
    #
    # Notas: 
    # X - num_movies x num_features: matriz das características dos filmes
    # Theta - num_users x num_features: matriz das características dos usuários
    # Y - num_movies x num_users: matriz de classificações de filmes por usuários
    # R - num_movies x num_users: matriz, onde R (i, j) = 1 se o i-ésimo filme 
    #       foi avaliado pelo j-ésimo usuário
    #
    # Você deve definir as seguintes variáveis ​​corretamente:
    #
    # X_grad - num_movies x num_features matrix, contendo as
    #   derivadas parciais com relação a cada elemento de X
    # Theta_grad - num_users x num_features: matriz, contendo as
    #   derivadas parciais com relação a cada elemento de Theta
    # =============================================================

    grad = np.hstack((X_grad.T.flatten(),Theta_grad.T.flatten()))

    return J, grad