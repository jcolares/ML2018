import os, sys
import pandas as pd
import numpy as np
from normalizacao import normalizar_caracteristica

x = [[500,2],[800,4], [1000,5]]
#y = [[3,4],[3,4],[3,4],[3,4],[3,4]]
y = [2,2,2,2,2]

x = np.array(x)
y = np.array(y)


x_mean = np.mean(x, axis=0)
x_std = np.std(x, axis=0)
x_norm = (x - x_mean)/x_std




print(normalizar_caracteristica(x, y))

'''
a = np.array([[1, 2], [3, 4]])
np.std(a)
np.std(a, axis=0)
array([ 1.,  1.])
np.std(a, axis=1)
array([ 0.5,  0.5])
'''
