#coding=ISO8859-1
#declara��o de encoding para possibilitar a utiliza��o desse arquivo vom o Linux

import matplotlib.pyplot as plt

#chamadas a bibliotecas {
import os, sys
import pandas as pd
import numpy as np
# }

#from custo_reglin_uni import custo_reglin_uni
from custo_reglin_uni import custo_reglin

#modifica��o no filepath para possibilitar a utiliza��o desse arquivo com o Linux
#filepath = "\ex1data1.txt"
filepath = "/ex1data1.txt"

def importarDados(filepath,names):
    path = os.getcwd() + filepath
    data = pd.read_csv(path, header=None, names=names)

    # adiciona uma coluna de 1s referente a variavel x0
    data.insert(0, 'Ones', 1)
    # a linha acima fazia parte do c�digo original, mas foi removida para possibilitar a plotagem do gr�fico.

    # separa os conjuntos de dados x (caracteristicas) e y (alvo)
    cols = data.shape[1]
    X = data.iloc[:,0:cols-1]
    y = data.iloc[:,cols-1:cols]

    # converte os valores em numpy arrays
    X = np.array(X.values)
    y = np.array(y.values)

    return X,y

X,y = importarDados(filepath,["Population","Profit"])

#Vers�o original abaixo tentava passar as duas colunas de X e provocava erro na gera��o do gr�fico
#plt.scatter(X, y, color='blue', marker='x')
plt.scatter(X[:,1], y, color='blue', marker='x')
plt.title('Popula��o da cidade x Lucro da filial')
plt.xlabel('Popula��o da cidade (10k)')
plt.ylabel('Lucro (10k)')
plt.savefig('plot1.1.png')
plt.show()
