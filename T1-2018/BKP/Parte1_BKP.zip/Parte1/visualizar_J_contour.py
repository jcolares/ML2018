#coding=ISO8859-1
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd 
from matplotlib import cm
from custo_reglin_uni import custo_reglin_uni

# Valores de theta0 e theta1 informados no enunciado do trabalho
theta0 = np.arange(-10, 10, 0.1)
theta1 = np.arange(-10, 10, 0.1)
#theta1 = np.arange(-1, 4, 0.01)

#carrega os dados do arquivo
dataset = pd.read_csv('ex1data1.txt', header = None)

#acrescenta uma coluna preenchida com 1s
dataset.insert(0, 'Ones', 1)

#separa o dataset em dois: X com duas colunas e y com uma
cols = dataset.shape[1]
x = dataset.iloc[:,0:cols-1]
y = dataset.iloc[:,cols-1:cols]

#converte os datasets em arrays
x = np.array(x.values)
y = np.array(y.values)

# Inicia os valores de J com zeros
J = np.zeros((len(theta0), len(theta1)))

# Preenche os valores sucessivos de J
for i in range(len(theta0)):
    for j in range(len(theta1)):
        t = [[theta0[i]], [theta1[j]]]
        J[i,j] = custo_reglin_uni(x, y, t)

# Transp�e J devido as fun��es contour/meshgrid
J = np.transpose(J)

# Plota a fun��o de custo utilizando levels como logspace. Range -1 ~ 4 devido ao
# range de theta1 e 20 pois o theta0 tem 20 valores (-10 at� 10)
fig = plt.figure()
fig, ax = plt.subplots()
ax.contour(theta0, theta1, J, levels=np.logspace(-1, 4, 20), color='blue')
#ax.plot(theta[0,0], theta[1,0], 'rx')
ax.plot(theta0, theta1, 'rx')
plt.xlabel('theta0')
plt.ylabel('theta1')
plt.show()
