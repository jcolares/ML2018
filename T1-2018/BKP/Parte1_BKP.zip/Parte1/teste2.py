#coding=ISO8859-1
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# Prepare the data
a = np.linspace(1, 10, 10)
b = np.linspace(1, 10, 10)

#Os limites e escalas podem ser diferentes, mas para cada x,
#precisa haver um y correspondente, portanto
'''
plt.plot(x[:,1], y, color="red")
plt.scatter(x[:,1], y)
plt.ylabel('banana')
plt.xlabel("ma��")
plt.legend()
plt.show()
'''
fig = plt.figure()
fig, ax = plt.subplots()
ax.contour(a, b)#, J, levels=np.logspace(-1, 4, 20), color='blue')
ax.plot(theta0, theta1, 'rx') #plota os pontos em red x's (rx)
plt.xlabel('theta0')
plt.ylabel('theta1')
plt.show()
